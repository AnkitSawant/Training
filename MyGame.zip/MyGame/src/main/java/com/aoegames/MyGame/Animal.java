package com.aoegames.MyGame;

public class Animal {

	int noOfLegs;
	boolean wings;
	
	public int getNoOfLegs() {
		return noOfLegs;
	}
	public void setNoOfLegs(int noOfLegs) {
		this.noOfLegs = noOfLegs;
	}
	public boolean isWings() {
		return wings;
	}
	public void setWings(boolean wings) {
		this.wings = wings;
	}
	
}

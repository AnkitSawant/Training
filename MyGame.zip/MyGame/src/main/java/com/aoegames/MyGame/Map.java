package com.aoegames.MyGame;

import java.util.ArrayList;
import java.util.List;

public class Map {

	Animal animal;
	Enemy enemy;
	Troops troops;
	List<Animal> animalList = new ArrayList(); 
	List<Enemy> enemyList = new ArrayList<Enemy>();
	List<Troops> troopsList = new ArrayList<Troops>();
	
	public List<Animal> getAnimal() {
		//return animal;
		return animalList;
	}
	public void setAnimal(Animal animal) {
		//this.animal = animal;
		animalList.add(animal);
	}
	public List<Enemy> getEnemy() {
		//return enemy;
		return enemyList;
	}
	public void setEnemy(Enemy enemy) {
		//this.enemy = enemy;
		enemyList.add(enemy);
	}
	public List<Troops> getTroops() {
		//return troops;
		return troopsList;
	}
	public void setTroops(Troops troops) {
		//this.troops = troops;
		troopsList.add(troops);
	}
	
	
}

package com.aoegames.MyGame;

public class Enemy {

	int noOfEnemy;
	String weapon;
	
	public int getNoOfEnemy() {
		return noOfEnemy;
	}
	public void setNoOfEnemy(int noOfEnemy) {
		this.noOfEnemy = noOfEnemy;
	}
	public String getWeapon() {
		return weapon;
	}
	public void setWeapon(String weapon) {
		this.weapon = weapon;
	}
	
}
